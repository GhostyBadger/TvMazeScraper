﻿using Microsoft.AspNetCore.Mvc;
using TvMazeScraper.Services;
using TvMazeScraper.Models;

namespace TvMazeScraper.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TvMazeController : ControllerBase
    {
        private readonly ITvMazeScraperService _tvMazeScraperService;

        public TvMazeController(ITvMazeScraperService tvMazeScraperService)
        {
            _tvMazeScraperService = tvMazeScraperService;
        }

        [HttpGet("shows")]
        public async Task<IActionResult> GetShows(int page = 1, int pageSize = 10)
        {
            var shows = await _tvMazeScraperService.GetShowsWithCastAsync(page, pageSize);
            return Ok(shows);
        }

        [HttpPost("scrape")]
        public async Task<IActionResult> ScrapeShows()
        {
            await _tvMazeScraperService.ScrapeAndStoreShowsAsync();
            return Ok("Scraping and storing shows completed.");
        }

    }

}
