﻿using Microsoft.EntityFrameworkCore;
using TvMazeScraper.Models;

namespace TvMazeScraper.Data
{
    public class TvMazeContext : DbContext
    {
        public TvMazeContext(DbContextOptions<TvMazeContext> options) : base(options) { }

        public DbSet<TVShow> TVShows { get; set; }
        public DbSet<CastMember> CastMembers { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
          
            modelBuilder.Entity<TVShow>()
                .HasKey(s => s.Id); 

            modelBuilder.Entity<TVShow>()
                .Property(s => s.Id)
                .ValueGeneratedOnAdd(); 

         
            modelBuilder.Entity<CastMember>()
                .HasKey(c => c.Id); 

            modelBuilder.Entity<CastMember>()
                .Property(c => c.Id)
                .ValueGeneratedOnAdd(); 

          
            modelBuilder.Entity<CastMember>()
                .HasOne(c => c.TVShow)
                .WithMany(s => s.Cast)
                .HasForeignKey(c => c.TVShowId)
                .OnDelete(DeleteBehavior.Cascade); 
        }
    }
}
