﻿namespace TvMazeScraper.Models
{
    public class CastMemberResponse
    {
        public Person Person { get; set; }
    }

    public class Person
    {
        public string Name { get; set; }
        public DateTime? Birthday { get; set; }
    }
}
