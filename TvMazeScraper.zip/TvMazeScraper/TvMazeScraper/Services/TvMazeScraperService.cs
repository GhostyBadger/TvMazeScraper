﻿using System.Net.Http;
using System.Net.Http.Json;
using TvMazeScraper.Data;
using TvMazeScraper.Models;
using Microsoft.EntityFrameworkCore;

namespace TvMazeScraper.Services
{
    public class TvMazeScraperService : ITvMazeScraperService
    {
        private readonly HttpClient _httpClient;
        private readonly TvMazeContext _context;

        public TvMazeScraperService(HttpClient httpClient, TvMazeContext context)
        {
            _httpClient = httpClient;
            _context = context;
        }
      
        public async Task ScrapeAndStoreShowsAsync()
        {
            int page = 0;
            bool hasMoreShows;

            try
            {
                do
                {
                    List<TVShow> shows = null;
                    try
                    {
                        shows = await _httpClient.GetFromJsonAsync<List<TVShow>>($"https://api.tvmaze.com/shows?page={page}");                        
                    }
                    catch (HttpRequestException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
                    {
                        Console.WriteLine($"Page {page} not found. Stopping the scraping process.");
                        break;
                    }
                    
                    hasMoreShows = shows != null && shows.Count > 0;

                    if (hasMoreShows)
                    {
                        foreach (var show in shows)
                        {
                            try
                            {
                                var castResponse = await _httpClient.GetFromJsonAsync<List<CastMemberResponse>>($"https://api.tvmaze.com/shows/{show.Id}/cast");

                                if (castResponse != null)
                                {
                                    show.Cast = castResponse
                                        .Where(c => !string.IsNullOrEmpty(c.Person.Name))
                                        .Select(c => new CastMember
                                        {
                                            Name = c.Person.Name,
                                            Birthday = c.Person.Birthday,
                                            TVShowId = 0
                                        }).ToList();
                                }
                            }
                            catch (HttpRequestException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
                            {
                                Console.WriteLine($"Cast for show ID {show.Id} not found. Skipping this show.");
                                continue;
                            }

                            var existingShow = await _context.TVShows.Include(s => s.Cast)
                                .FirstOrDefaultAsync(s => s.Id == show.Id);

                            if (existingShow == null)
                            {
                                _context.TVShows.Add(show);
                                await _context.SaveChangesAsync();

                                foreach (var cast in show.Cast)
                                {
                                    cast.TVShowId = show.Id;
                                }
                                await _context.SaveChangesAsync(); 
                            }
                            else
                            {
                                _context.Entry(existingShow).CurrentValues.SetValues(show);
                                existingShow.Cast = show.Cast;
                                await _context.SaveChangesAsync();
                            }
                        }

                        page++;
                    }

                } while (hasMoreShows);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                throw; 
            }
        }

    public async Task<IEnumerable<TVShow>> GetShowsWithCastAsync(int pageNumber, int pageSize)
        {
            return await _context.TVShows
                .Include(s => s.Cast)
                .OrderBy(s => s.Id)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();
        }
    }
}
