﻿using TvMazeScraper.Models;

namespace TvMazeScraper.Services
{
    public interface ITvMazeScraperService
    {
        Task ScrapeAndStoreShowsAsync();
        Task<IEnumerable<TVShow>> GetShowsWithCastAsync(int pageNumber, int pageSize);
    }
}
